# Proyecto Web — Jair Dev

Estructura del repositorio con los dos proyectos principales.

## Proyectos

### /nexum
Sitio principal de NEXUM — Ciberseguridad & Desarrollo de Software.

```
nexum/
├── index.html          ← Página principal
├── css/
│   └── styles.css      ← Todos los estilos
├── js/
│   ├── main.js         ← Lógica principal, navegación, animaciones
│   ├── chat.js         ← Chatbot y asistente virtual
│   └── tools.js        ← Herramientas: scanner, OSINT, QR, etc.
└── assets/
    └── btc-nexum.jpg   ← QR de pago Bitcoin/Yape
```

### /lovemotion
Landing page de LoveMotion — Dedicatorias animadas con partículas.

```
lovemotion/
├── index.html          ← Página principal
├── css/
│   └── styles.css      ← Estilos completos
└── js/
    └── app.js          ← Canvas animations, modal de pedidos, preview
```

## Cómo usar

Abrir `index.html` de cada proyecto directamente en el navegador,
o servirlos con cualquier servidor estático (Vercel, Netlify, GitHub Pages).

---
*Desarrollado por @jair.dev*
